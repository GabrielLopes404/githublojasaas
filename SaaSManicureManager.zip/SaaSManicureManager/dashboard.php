<?php
require_once 'config/security.php';

if (!isLoggedIn()) {
    header('Location: /index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SaaS Salão</title>
    <link rel="stylesheet" href="public/css/main.css">
    <link rel="stylesheet" href="public/css/dashboard.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
</head>
<body class="dashboard">
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>💅 SaaS Salão</h2>
        </div>
        
        <ul class="sidebar-menu">
            <li><a href="#" class="active" data-view="dashboard">📊 Dashboard</a></li>
            <li><a href="#" data-view="calendar">📅 Agenda</a></li>
            <li><a href="#" data-view="clients">👥 Clientes</a></li>
            <li><a href="#" data-view="services">✨ Serviços</a></li>
            <li><a href="#" data-view="financial">💰 Financeiro</a></li>
            <li><a href="#" data-view="stock">📦 Estoque</a></li>
            <li><a href="#" data-view="reports">📈 Relatórios</a></li>
            <li><a href="#" data-view="settings">⚙️ Configurações</a></li>
        </ul>
    </aside>
    
    <main class="main-content">
        <div class="top-bar">
            <button class="mobile-menu-btn" id="mobile-menu-btn">☰</button>
            <h1 id="page-title">Dashboard</h1>
            <div class="top-bar-actions">
                <button class="theme-toggle" id="theme-toggle">🌙</button>
                <div class="user-info">
                    <div class="user-avatar" id="user-avatar">A</div>
                    <div class="user-details">
                        <h4 id="user-name">Carregando...</h4>
                        <p id="user-email"></p>
                    </div>
                </div>
                <button class="btn btn-error" id="logout-btn">Sair</button>
            </div>
        </div>
        
        <div id="main-content-area">
            <div class="loading" style="margin: 50px auto; display: block;"></div>
        </div>
    </main>
    
    <script src="public/js/animations.js"></script>
    <script src="public/js/dashboard.js"></script>
</body>
</html>
