#!/usr/bin/env python3
"""
SERVIDOR DE DEMONSTRAÇÃO APENAS
Este servidor é APENAS para visualização no Replit.
O projeto REAL deve rodar no XAMPP com MySQL conforme especificado.
"""

import http.server
import socketserver

PORT = 5000

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        super().end_headers()

Handler = MyHTTPRequestHandler

with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    print(f"✅ Servidor de demonstração rodando na porta {PORT}")
    print(f"⚠️  IMPORTANTE: Este projeto foi feito para rodar no XAMPP local!")
    print(f"📥 Baixe o código e siga as instruções do README.md")
    httpd.serve_forever()
