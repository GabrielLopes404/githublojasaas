<?php
require_once 'config/security.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaaS Gestão para Salões - Login</title>
    <link rel="stylesheet" href="public/css/main.css">
    <link rel="stylesheet" href="public/css/auth.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <h1>💅 SaaS Salão</h1>
                <p>Gestão Inteligente para seu Negócio</p>
            </div>
            
            <div id="alert-container"></div>
            
            <div class="auth-tabs">
                <button class="tab-btn active" data-tab="login">Login</button>
                <button class="tab-btn" data-tab="register">Cadastro</button>
            </div>
            
            <div id="login-tab" class="tab-content active">
                <form id="login-form" class="auth-form">
                    <div class="form-group">
                        <label for="login-email">E-mail</label>
                        <input type="email" id="login-email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="login-password">Senha</label>
                        <input type="password" id="login-password" name="password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Entrar</button>
                    
                    <a href="#" class="forgot-password" id="show-forgot">Esqueci minha senha</a>
                </form>
            </div>
            
            <div id="register-tab" class="tab-content">
                <form id="register-form" class="auth-form">
                    <div class="form-group">
                        <label for="register-name">Nome Completo</label>
                        <input type="text" id="register-name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="register-email">E-mail</label>
                        <input type="email" id="register-email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="register-phone">Telefone</label>
                        <input type="tel" id="register-phone" name="phone" placeholder="(11) 99999-9999">
                    </div>
                    
                    <div class="form-group">
                        <label for="register-password">Senha (mínimo 8 caracteres)</label>
                        <input type="password" id="register-password" name="password" required minlength="8">
                    </div>
                    
                    <div class="form-group">
                        <label for="register-confirm">Confirmar Senha</label>
                        <input type="password" id="register-confirm" name="confirm_password" required minlength="8">
                    </div>
                    
                    <div class="form-group checkbox">
                        <label>
                            <input type="checkbox" name="terms" required>
                            Li e aceito os <a href="#" target="_blank">Termos de Uso</a> e <a href="#" target="_blank">Política de Privacidade</a>
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Criar Conta</button>
                </form>
            </div>
            
            <div id="forgot-tab" class="tab-content">
                <button class="back-btn" id="back-to-login">&larr; Voltar</button>
                <form id="forgot-form" class="auth-form">
                    <p class="info-text">Digite seu e-mail para receber instruções de recuperação de senha.</p>
                    
                    <div class="form-group">
                        <label for="forgot-email">E-mail</label>
                        <input type="email" id="forgot-email" name="email" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Recuperar Senha</button>
                </form>
            </div>
        </div>
    </div>
    
    <script src="public/js/animations.js"></script>
    <script src="public/js/auth.js"></script>
</body>
</html>
