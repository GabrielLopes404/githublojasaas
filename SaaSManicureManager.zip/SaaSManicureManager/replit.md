# SaaS para Gestão de Salões de Beleza

## Overview

This is a comprehensive salon management SaaS system designed for manicurists, beauty clinics, and independent salons. The system is built as a PHP-based application intended to run on XAMPP (Apache + PHP 8.x + MySQL) on local machines, not on Replit's cloud infrastructure.

The application provides complete business management capabilities including appointment scheduling, client management, service catalog, inventory control, payment processing (stub), LGPD compliance, and analytics dashboards. The UI features a responsive design with a rosé/lilac/white/gold color palette and supports both light and dark modes.

**Key Note:** This is explicitly designed for local XAMPP deployment. The repository includes a Python demonstration server solely for Replit preview purposes, but the actual application requires MySQL and Apache which are not Replit's native stack.

## Recent Changes

**October 22, 2025** - MVP Completed + Ultra Professional Design
- ✅ Complete authentication system with bcrypt, CSRF protection, and session management
- ✅ Full REST API for clients, services, appointments, stock, and dashboard
- ✅ LGPD compliance (data export, account deletion, consent tracking, audit logs)
- ✅ **ULTRA PROFESSIONAL UI** with glassmorphism, animated gradients, and particles
- ✅ **Premium animations:** confetti, ripple effects, 3D transforms, backdrop blur
- ✅ **Advanced interactions:** hover effects, smooth transitions (cubic-bezier), floating particles
- ✅ Responsive rosé/lilac themed UI with smooth light/dark mode toggle (0.5s)
- ✅ MySQL database schema with complete relationships and indexes
- ✅ Comprehensive documentation in Portuguese (README.md, INSTRUCOES_INSTALACAO.md, MELHORIAS_VISUAIS.md)
- ✅ Security: prepared statements, input sanitization, XSS protection
- ✅ Default admin account and sample data included
- ✅ Ready for XAMPP deployment
- ✅ **Professional design level:** Stripe/Vercel quality

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- Pure HTML5/CSS3/JavaScript (no frameworks)
- Responsive design for desktop and mobile
- CSS custom properties for theming (light/dark mode)
- Client-side routing for SPA-like experience within dashboard

**Design Decisions:**
- **No Framework Approach:** Built with vanilla JavaScript to minimize dependencies and maintain simplicity for local XAMPP deployment
- **Theme System:** CSS variables enable dynamic theme switching (rosé/lilac/white/gold palette)
- **Modular CSS:** Separate stylesheets for authentication (`auth.css`), dashboard (`dashboard.css`), and global styles (`main.css`)
- **Progressive Enhancement:** Core functionality works without JavaScript, enhanced UX with JS enabled

**Frontend Components:**
- Authentication pages (login, register, password recovery)
- Dashboard with sidebar navigation
- Client management interface
- Appointment calendar (drag & drop planned)
- Service and inventory management
- Statistics and reporting views

### Backend Architecture

**Technology Stack:**
- PHP 8.x (pure PHP, no frameworks)
- PDO for database abstraction
- RESTful API structure
- Session-based authentication

**Design Decisions:**
- **No Framework Policy:** Deliberately avoids Laravel/Composer to maintain simplicity and XAMPP compatibility
- **REST API Pattern:** Clean separation between frontend and backend logic via `/api/` endpoints
- **Security First:** Implements bcrypt password hashing, prepared statements (PDO), CSRF tokens, and input validation
- **Modular Structure:** Organized into logical directories (api, config, database, public)

**Core API Endpoints:**
- `/api/auth/` - Authentication (login, register, password recovery, session management)
- `/api/clients/` - Client CRUD operations and history
- `/api/appointments/` - Appointment scheduling and management
- `/api/services/` - Service catalog management
- `/api/inventory/` - Stock control
- `/api/payments/` - Payment processing (stub for future integration)
- `/api/reports/` - Dashboard statistics and analytics

**Security Mechanisms:**
- Password hashing using bcrypt
- SQL injection prevention via prepared statements
- CSRF token validation
- Input sanitization and validation
- Session management with secure cookies
- LGPD compliance (data export and deletion)

### Data Storage

**Database:** MySQL/MariaDB

**Schema Highlights:**
- Users table with authentication credentials
- Clients table with full contact and history
- Appointments with scheduling and status tracking
- Services catalog with pricing
- Inventory management with stock levels
- Audit logs for compliance
- Payment records (prepared for integration)

**Design Decisions:**
- **MySQL Choice:** Selected for XAMPP compatibility as specified (not PostgreSQL)
- **Normalized Schema:** Proper foreign key relationships for data integrity
- **Audit Trail:** Comprehensive logging for LGPD compliance and business intelligence
- **Import-Ready:** Includes `database/schema.sql` for easy setup via phpMyAdmin or CLI

### Authentication & Authorization

**Authentication Method:** Session-based with secure cookies

**Flow:**
1. Login credentials validated against bcrypt-hashed passwords
2. Session created with CSRF token
3. User data stored in session
4. `/api/auth/me.php` validates session on each request

**Design Rationale:**
- Session-based chosen over JWT for simplicity in PHP environment
- CSRF tokens protect against cross-site request forgery
- Secure cookie flags prevent XSS attacks
- Future roadmap includes role-based access control for multi-user scenarios

## External Dependencies

### Required Local Environment

**XAMPP Components:**
- Apache 2.4+ (web server)
- PHP 8.x (runtime environment)
- MySQL/MariaDB (database server)
- phpMyAdmin (database management, optional)

**Browser Requirements:**
- Modern browser with ES6+ JavaScript support
- CSS Grid and Flexbox support
- Local Storage API for theme persistence

### Planned Future Integrations

**Payment Gateways (Stub Implementation):**
- Stripe API (prepared endpoint structure)
- MercadoPago (prepared endpoint structure)

**Communication Services (Placeholder):**
- Email notifications (appointment confirmations, reminders)
- WhatsApp API integration (reminders and updates)

**Potential Migration Path:**
- Future evolution to Node.js/Next.js
- Microservices architecture
- API-first design already supports this transition

### Database Migration

**Current:** Import via `database/schema.sql`

**Process:**
```sql
mysql -u root -p < database/schema.sql
```

Or via phpMyAdmin import interface.

### No External Package Dependencies

- No Composer packages
- No npm dependencies
- No PHP frameworks
- Pure vanilla implementation for maximum portability