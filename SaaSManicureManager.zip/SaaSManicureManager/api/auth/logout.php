<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

requireLogin();

try {
    $database = new Database();
    $db = $database->getConnection();
    
    logAudit($db, $_SESSION['user_id'], 'user_logout', 'Logout realizado');
    
    session_destroy();
    
    echo json_encode(['success' => true, 'message' => 'Logout realizado com sucesso']);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao fazer logout']);
}
?>
