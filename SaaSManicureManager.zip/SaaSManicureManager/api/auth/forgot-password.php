<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['csrf_token'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Token CSRF ausente']);
    exit;
}

validateCSRF($data['csrf_token']);

$email = sanitizeInput($data['email'] ?? '');

if (empty($email) || !validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'E-mail inválido']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("SELECT id, name FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Se o e-mail existir, você receberá instruções de recuperação'
        ]);
        exit;
    }
    
    $user = $stmt->fetch();
    $reset_token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    $stmt = $db->prepare("
        UPDATE users 
        SET password_reset_token = :token, password_reset_expires = :expires 
        WHERE id = :id
    ");
    
    $stmt->execute([
        'token' => $reset_token,
        'expires' => $expires,
        'id' => $user['id']
    ]);
    
    logAudit($db, $user['id'], 'password_reset_requested', 'Token de recuperação gerado');
    
    echo json_encode([
        'success' => true,
        'message' => 'Instruções enviadas para o e-mail cadastrado',
        'debug_token' => $reset_token
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao processar solicitação']);
}
?>
