<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['csrf_token'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Token CSRF ausente']);
    exit;
}

validateCSRF($data['csrf_token']);

$name = sanitizeInput($data['name'] ?? '');
$email = sanitizeInput($data['email'] ?? '');
$phone = sanitizeInput($data['phone'] ?? '');
$password = $data['password'] ?? '';
$confirm_password = $data['confirm_password'] ?? '';

if (empty($name) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Preencha todos os campos obrigatórios']);
    exit;
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'E-mail inválido']);
    exit;
}

if (strlen($password) < 8) {
    echo json_encode(['success' => false, 'message' => 'A senha deve ter no mínimo 8 caracteres']);
    exit;
}

if ($password !== $confirm_password) {
    echo json_encode(['success' => false, 'message' => 'As senhas não conferem']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'E-mail já cadastrado']);
        exit;
    }
    
    $password_hash = hashPassword($password);
    $verification_token = bin2hex(random_bytes(32));
    
    $stmt = $db->prepare("
        INSERT INTO users (name, email, phone, password_hash, email_verification_token, role) 
        VALUES (:name, :email, :phone, :password_hash, :verification_token, 'professional')
    ");
    
    $stmt->execute([
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'password_hash' => $password_hash,
        'verification_token' => $verification_token
    ]);
    
    $user_id = $db->lastInsertId();
    
    logAudit($db, $user_id, 'user_registered', 'Novo usuário registrado');
    
    $stmt = $db->prepare("
        INSERT INTO privacy_consents (user_id, consent_type, terms_version, ip_address, user_agent) 
        VALUES (:user_id, 'user', '1.0', :ip, :user_agent)
    ");
    
    $stmt->execute([
        'user_id' => $user_id,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Cadastro realizado com sucesso! Faça login para continuar.'
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao criar conta: ' . $e->getMessage()]);
}
?>
