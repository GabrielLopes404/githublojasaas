<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($method === 'GET') {
        $category = $_GET['category'] ?? '';
        $status = $_GET['status'] ?? 'active';
        
        $sql = "SELECT * FROM services WHERE status = :status";
        $params = ['status' => $status];
        
        if (!empty($category)) {
            $sql .= " AND category = :category";
            $params['category'] = $category;
        }
        
        $sql .= " ORDER BY name ASC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $services = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'services' => $services]);
        
    } elseif ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        validateCSRF($data['csrf_token'] ?? '');
        
        $name = sanitizeInput($data['name'] ?? '');
        $description = sanitizeInput($data['description'] ?? '');
        $duration_minutes = (int)($data['duration_minutes'] ?? 30);
        $price = (float)($data['price'] ?? 0);
        $category = sanitizeInput($data['category'] ?? 'outros');
        $commission_percentage = (float)($data['commission_percentage'] ?? 0);
        
        if (empty($name) || $price <= 0 || $duration_minutes <= 0) {
            echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
            exit;
        }
        
        $stmt = $db->prepare("
            INSERT INTO services (name, description, duration_minutes, price, category, commission_percentage) 
            VALUES (:name, :description, :duration_minutes, :price, :category, :commission_percentage)
        ");
        
        $stmt->execute([
            'name' => $name,
            'description' => $description,
            'duration_minutes' => $duration_minutes,
            'price' => $price,
            'category' => $category,
            'commission_percentage' => $commission_percentage
        ]);
        
        $service_id = $db->lastInsertId();
        
        logAudit($db, $_SESSION['user_id'], 'service_created', "Serviço ID: $service_id");
        
        echo json_encode([
            'success' => true,
            'message' => 'Serviço cadastrado com sucesso',
            'service_id' => $service_id
        ]);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
