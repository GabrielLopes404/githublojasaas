<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$method = $_SERVER['REQUEST_METHOD'];
$client_id = $_GET['id'] ?? 0;

if (!$client_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID do cliente não fornecido']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($method === 'GET') {
        $stmt = $db->prepare("SELECT * FROM clients WHERE id = :id");
        $stmt->execute(['id' => $client_id]);
        $client = $stmt->fetch();
        
        if (!$client) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Cliente não encontrado']);
            exit;
        }
        
        $appointmentsStmt = $db->prepare("
            SELECT a.*, s.name as service_name, u.name as professional_name 
            FROM appointments a
            LEFT JOIN services s ON a.service_id = s.id
            LEFT JOIN users u ON a.professional_id = u.id
            WHERE a.client_id = :client_id
            ORDER BY a.appointment_date DESC, a.appointment_time DESC
            LIMIT 20
        ");
        $appointmentsStmt->execute(['client_id' => $client_id]);
        $appointments = $appointmentsStmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'client' => $client,
            'appointments' => $appointments
        ]);
        
    } elseif ($method === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        validateCSRF($data['csrf_token'] ?? '');
        
        $name = sanitizeInput($data['name'] ?? '');
        $email = sanitizeInput($data['email'] ?? '');
        $phone = sanitizeInput($data['phone'] ?? '');
        $cpf = sanitizeInput($data['cpf'] ?? '');
        $birth_date = sanitizeInput($data['birth_date'] ?? '');
        $address = sanitizeInput($data['address'] ?? '');
        $notes = sanitizeInput($data['notes'] ?? '');
        $status = sanitizeInput($data['status'] ?? 'active');
        
        if (empty($name) || empty($phone)) {
            echo json_encode(['success' => false, 'message' => 'Nome e telefone são obrigatórios']);
            exit;
        }
        
        $stmt = $db->prepare("
            UPDATE clients 
            SET name = :name, email = :email, phone = :phone, cpf = :cpf, 
                birth_date = :birth_date, address = :address, notes = :notes, status = :status
            WHERE id = :id
        ");
        
        $stmt->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'cpf' => $cpf,
            'birth_date' => $birth_date ?: null,
            'address' => $address,
            'notes' => $notes,
            'status' => $status,
            'id' => $client_id
        ]);
        
        logAudit($db, $_SESSION['user_id'], 'client_updated', "Cliente ID: $client_id");
        
        echo json_encode(['success' => true, 'message' => 'Cliente atualizado com sucesso']);
        
    } elseif ($method === 'DELETE') {
        $stmt = $db->prepare("DELETE FROM clients WHERE id = :id");
        $stmt->execute(['id' => $client_id]);
        
        logAudit($db, $_SESSION['user_id'], 'client_deleted', "Cliente ID: $client_id");
        
        echo json_encode(['success' => true, 'message' => 'Cliente excluído com sucesso']);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
