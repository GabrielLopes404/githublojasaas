<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($method === 'GET') {
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? 'active';
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        $sql = "SELECT * FROM clients WHERE status = :status";
        $params = ['status' => $status];
        
        if (!empty($search)) {
            $sql .= " AND (name LIKE :search OR phone LIKE :search OR email LIKE :search)";
            $params['search'] = "%$search%";
        }
        
        $sql .= " ORDER BY name ASC LIMIT :limit OFFSET :offset";
        
        $stmt = $db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        $clients = $stmt->fetchAll();
        
        $countStmt = $db->prepare("SELECT COUNT(*) as total FROM clients WHERE status = :status");
        $countStmt->execute(['status' => $status]);
        $total = $countStmt->fetch()['total'];
        
        echo json_encode([
            'success' => true,
            'clients' => $clients,
            'total' => $total
        ]);
        
    } elseif ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        validateCSRF($data['csrf_token'] ?? '');
        
        $name = sanitizeInput($data['name'] ?? '');
        $email = sanitizeInput($data['email'] ?? '');
        $phone = sanitizeInput($data['phone'] ?? '');
        $cpf = sanitizeInput($data['cpf'] ?? '');
        $birth_date = sanitizeInput($data['birth_date'] ?? '');
        $address = sanitizeInput($data['address'] ?? '');
        $notes = sanitizeInput($data['notes'] ?? '');
        
        if (empty($name) || empty($phone)) {
            echo json_encode(['success' => false, 'message' => 'Nome e telefone são obrigatórios']);
            exit;
        }
        
        $stmt = $db->prepare("
            INSERT INTO clients (name, email, phone, cpf, birth_date, address, notes) 
            VALUES (:name, :email, :phone, :cpf, :birth_date, :address, :notes)
        ");
        
        $stmt->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'cpf' => $cpf,
            'birth_date' => $birth_date ?: null,
            'address' => $address,
            'notes' => $notes
        ]);
        
        $client_id = $db->lastInsertId();
        
        logAudit($db, $_SESSION['user_id'], 'client_created', "Cliente ID: $client_id");
        
        echo json_encode([
            'success' => true,
            'message' => 'Cliente cadastrado com sucesso',
            'client_id' => $client_id
        ]);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
