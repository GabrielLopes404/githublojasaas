<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($method === 'GET') {
        $date = $_GET['date'] ?? date('Y-m-d');
        $professional_id = $_GET['professional_id'] ?? $_SESSION['user_id'];
        $status = $_GET['status'] ?? '';
        
        $sql = "
            SELECT a.*, 
                   c.name as client_name, c.phone as client_phone,
                   s.name as service_name, s.price as service_price,
                   u.name as professional_name,
                   p.payment_status, p.payment_method
            FROM appointments a
            LEFT JOIN clients c ON a.client_id = c.id
            LEFT JOIN services s ON a.service_id = s.id
            LEFT JOIN users u ON a.professional_id = u.id
            LEFT JOIN payments p ON a.id = p.appointment_id
            WHERE a.appointment_date = :date
        ";
        
        $params = ['date' => $date];
        
        if ($professional_id !== 'all') {
            $sql .= " AND a.professional_id = :professional_id";
            $params['professional_id'] = $professional_id;
        }
        
        if (!empty($status)) {
            $sql .= " AND a.status = :status";
            $params['status'] = $status;
        }
        
        $sql .= " ORDER BY a.appointment_time ASC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $appointments = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'appointments' => $appointments]);
        
    } elseif ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        validateCSRF($data['csrf_token'] ?? '');
        
        $client_id = (int)($data['client_id'] ?? 0);
        $professional_id = (int)($data['professional_id'] ?? $_SESSION['user_id']);
        $service_id = (int)($data['service_id'] ?? 0);
        $appointment_date = sanitizeInput($data['appointment_date'] ?? '');
        $appointment_time = sanitizeInput($data['appointment_time'] ?? '');
        $notes = sanitizeInput($data['notes'] ?? '');
        
        if (!$client_id || !$service_id || !$appointment_date || !$appointment_time) {
            echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
            exit;
        }
        
        $serviceStmt = $db->prepare("SELECT duration_minutes FROM services WHERE id = :id");
        $serviceStmt->execute(['id' => $service_id]);
        $service = $serviceStmt->fetch();
        
        if (!$service) {
            echo json_encode(['success' => false, 'message' => 'Serviço não encontrado']);
            exit;
        }
        
        $end_time = date('H:i:s', strtotime($appointment_time) + ($service['duration_minutes'] * 60));
        
        $conflictStmt = $db->prepare("
            SELECT id FROM appointments 
            WHERE professional_id = :professional_id 
            AND appointment_date = :date 
            AND status NOT IN ('cancelled', 'no_show')
            AND (
                (appointment_time <= :start_time AND end_time > :start_time)
                OR (appointment_time < :end_time AND end_time >= :end_time)
                OR (appointment_time >= :start_time AND end_time <= :end_time)
            )
        ");
        
        $conflictStmt->execute([
            'professional_id' => $professional_id,
            'date' => $appointment_date,
            'start_time' => $appointment_time,
            'end_time' => $end_time
        ]);
        
        if ($conflictStmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Horário já ocupado']);
            exit;
        }
        
        $stmt = $db->prepare("
            INSERT INTO appointments 
            (client_id, professional_id, service_id, appointment_date, appointment_time, end_time, notes, status) 
            VALUES (:client_id, :professional_id, :service_id, :date, :time, :end_time, :notes, 'scheduled')
        ");
        
        $stmt->execute([
            'client_id' => $client_id,
            'professional_id' => $professional_id,
            'service_id' => $service_id,
            'date' => $appointment_date,
            'time' => $appointment_time,
            'end_time' => $end_time,
            'notes' => $notes
        ]);
        
        $appointment_id = $db->lastInsertId();
        
        logAudit($db, $_SESSION['user_id'], 'appointment_created', "Agendamento ID: $appointment_id");
        
        echo json_encode([
            'success' => true,
            'message' => 'Agendamento criado com sucesso',
            'appointment_id' => $appointment_id
        ]);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
