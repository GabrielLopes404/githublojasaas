<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$method = $_SERVER['REQUEST_METHOD'];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($method === 'GET') {
        $status = $_GET['status'] ?? 'active';
        $low_stock = isset($_GET['low_stock']) && $_GET['low_stock'] === '1';
        
        $sql = "SELECT * FROM stock_items WHERE status = :status";
        $params = ['status' => $status];
        
        if ($low_stock) {
            $sql .= " AND quantity <= min_quantity";
        }
        
        $sql .= " ORDER BY name ASC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $items = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'items' => $items]);
        
    } elseif ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        validateCSRF($data['csrf_token'] ?? '');
        
        $name = sanitizeInput($data['name'] ?? '');
        $description = sanitizeInput($data['description'] ?? '');
        $quantity = (int)($data['quantity'] ?? 0);
        $min_quantity = (int)($data['min_quantity'] ?? 10);
        $unit = sanitizeInput($data['unit'] ?? 'un');
        $cost_price = (float)($data['cost_price'] ?? 0);
        $supplier = sanitizeInput($data['supplier'] ?? '');
        
        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Nome é obrigatório']);
            exit;
        }
        
        $stmt = $db->prepare("
            INSERT INTO stock_items (name, description, quantity, min_quantity, unit, cost_price, supplier) 
            VALUES (:name, :description, :quantity, :min_quantity, :unit, :cost_price, :supplier)
        ");
        
        $stmt->execute([
            'name' => $name,
            'description' => $description,
            'quantity' => $quantity,
            'min_quantity' => $min_quantity,
            'unit' => $unit,
            'cost_price' => $cost_price,
            'supplier' => $supplier
        ]);
        
        $item_id = $db->lastInsertId();
        
        logAudit($db, $_SESSION['user_id'], 'stock_item_created', "Item ID: $item_id");
        
        echo json_encode([
            'success' => true,
            'message' => 'Item adicionado ao estoque',
            'item_id' => $item_id
        ]);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
