<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');
    $month_end = date('Y-m-t');
    
    $todayStmt = $db->prepare("
        SELECT COUNT(*) as total,
               SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
               SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
               SUM(CASE WHEN status = 'no_show' THEN 1 ELSE 0 END) as no_shows
        FROM appointments 
        WHERE appointment_date = :today
    ");
    $todayStmt->execute(['today' => $today]);
    $todayStats = $todayStmt->fetch();
    
    $monthStmt = $db->prepare("
        SELECT COUNT(*) as total_appointments,
               SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed,
               SUM(CASE WHEN p.payment_status = 'completed' THEN p.amount ELSE 0 END) as revenue
        FROM appointments a
        LEFT JOIN payments p ON a.id = p.appointment_id
        WHERE a.appointment_date BETWEEN :start AND :end
    ");
    $monthStmt->execute(['start' => $month_start, 'end' => $month_end]);
    $monthStats = $monthStmt->fetch();
    
    $clientsStmt = $db->query("SELECT COUNT(*) as total FROM clients WHERE status = 'active'");
    $clientsTotal = $clientsStmt->fetch()['total'];
    
    $servicesStmt = $db->query("SELECT COUNT(*) as total FROM services WHERE status = 'active'");
    $servicesTotal = $servicesStmt->fetch()['total'];
    
    $upcomingStmt = $db->prepare("
        SELECT a.*, c.name as client_name, s.name as service_name
        FROM appointments a
        LEFT JOIN clients c ON a.client_id = c.id
        LEFT JOIN services s ON a.service_id = s.id
        WHERE a.appointment_date >= :today 
        AND a.status IN ('scheduled', 'confirmed')
        ORDER BY a.appointment_date ASC, a.appointment_time ASC
        LIMIT 5
    ");
    $upcomingStmt->execute(['today' => $today]);
    $upcoming = $upcomingStmt->fetchAll();
    
    $topServicesStmt = $db->prepare("
        SELECT s.name, COUNT(*) as count, SUM(p.amount) as revenue
        FROM appointments a
        LEFT JOIN services s ON a.service_id = s.id
        LEFT JOIN payments p ON a.id = p.appointment_id
        WHERE a.appointment_date BETWEEN :start AND :end
        AND a.status = 'completed'
        GROUP BY s.id
        ORDER BY count DESC
        LIMIT 5
    ");
    $topServicesStmt->execute(['start' => $month_start, 'end' => $month_end]);
    $topServices = $topServicesStmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'today' => $todayStats,
        'month' => $monthStats,
        'totals' => [
            'clients' => $clientsTotal,
            'services' => $servicesTotal
        ],
        'upcoming' => $upcoming,
        'top_services' => $topServices
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
