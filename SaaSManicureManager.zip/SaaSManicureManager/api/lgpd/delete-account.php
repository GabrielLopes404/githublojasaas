<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

requireLogin();

$data = json_decode(file_get_contents('php://input'), true);
validateCSRF($data['csrf_token'] ?? '');

$confirmation = sanitizeInput($data['confirmation'] ?? '');

if ($confirmation !== 'EXCLUIR') {
    echo json_encode(['success' => false, 'message' => 'Confirmação inválida']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $user_id = $_SESSION['user_id'];
    
    logAudit($db, $user_id, 'account_deletion_requested', 'Usuário solicitou exclusão da conta');
    
    $stmt = $db->prepare("DELETE FROM users WHERE id = :id");
    $stmt->execute(['id' => $user_id]);
    
    session_destroy();
    
    echo json_encode([
        'success' => true,
        'message' => 'Conta excluída com sucesso'
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao excluir conta']);
}
?>
