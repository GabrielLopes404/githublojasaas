<?php
require_once '../../config/database.php';
require_once '../../config/security.php';

header('Content-Type: application/json');

requireLogin();

$user_id = $_SESSION['user_id'];
$format = $_GET['format'] ?? 'json';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $userData = [];
    
    $userStmt = $db->prepare("SELECT id, name, email, phone, role, created_at FROM users WHERE id = :id");
    $userStmt->execute(['id' => $user_id]);
    $userData['user'] = $userStmt->fetch();
    
    $appointmentsStmt = $db->prepare("
        SELECT a.*, c.name as client_name, s.name as service_name 
        FROM appointments a
        LEFT JOIN clients c ON a.client_id = c.id
        LEFT JOIN services s ON a.service_id = s.id
        WHERE a.professional_id = :user_id
    ");
    $appointmentsStmt->execute(['user_id' => $user_id]);
    $userData['appointments'] = $appointmentsStmt->fetchAll();
    
    $logsStmt = $db->prepare("SELECT * FROM audit_logs WHERE user_id = :user_id ORDER BY created_at DESC");
    $logsStmt->execute(['user_id' => $user_id]);
    $userData['audit_logs'] = $logsStmt->fetchAll();
    
    logAudit($db, $user_id, 'data_exported', "Formato: $format");
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="meus_dados.csv"');
        
        echo "Tipo,Dados\n";
        echo "Usuário," . json_encode($userData['user']) . "\n";
        foreach ($userData['appointments'] as $apt) {
            echo "Agendamento," . json_encode($apt) . "\n";
        }
    } else {
        echo json_encode([
            'success' => true,
            'data' => $userData,
            'exported_at' => date('Y-m-d H:i:s')
        ], JSON_PRETTY_PRINT);
    }
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao exportar dados']);
}
?>
