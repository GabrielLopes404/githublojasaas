# 💅 SaaS para Gestão de Salões de Beleza

## ✨ SISTEMA ULTRA SOFISTICADO E PROFISSIONAL ✨

Sistema completo de gestão com **DESIGN PREMIUM** para manicures, clínicas de beleza e salões independentes.

### 🎨 Design Ultra Profissional

- 🌟 **Animações sofisticadas** com transições suaves (cubic-bezier)
- 💎 **Glassmorphism** (efeito de vidro com backdrop blur 30px)
- 🌈 **Gradientes animados** que mudam de posição
- ✨ **Partículas flutuantes** em background
- 🎆 **Confete animado** ao fazer login e abrir dashboard
- 💫 **Efeitos de hover** com transformações 3D
- 🎭 **Modal com animações** bounce e slide
- 🌓 **Modo claro/escuro** com transição suave de 0.5s
- 📱 **100% responsivo** com animações preservadas

### 🎯 Interações Avançadas

- 🔘 **Botões com efeito ripple** ao clicar
- 📦 **Cards que elevam** ao passar o mouse (-8px)
- 📝 **Inputs com foco animado** e backdrop blur
- 🎨 **Sidebar com transição** suave em mobile
- ✨ **Scrollbar personalizada** com gradient
- 💫 **Loading premium** com dots animados

## 📋 Características Funcionais

- ✅ Sistema de autenticação completo (registro, login, recuperação de senha)
- ✅ Gestão de agendamentos com calendário
- ✅ CRUD completo de clientes com histórico
- ✅ Cadastro de serviços e preços
- ✅ Controle de estoque básico
- ✅ Dashboard com estatísticas e relatórios
- ✅ Conformidade LGPD (exportação e exclusão de dados)
- ✅ Sistema de pagamentos (preparado para integração)
- ✅ Logs de auditoria
- ✅ Interface responsiva com modo claro/escuro
- ✅ Tema rosé/lilás/branco/dourado

## 🚀 Instalação no XAMPP

### Pré-requisitos

- XAMPP com PHP 8.x e MySQL/MariaDB
- Navegador web moderno

### Passo 1: Copiar Arquivos

1. Copie toda a pasta do projeto para `C:\xampp\htdocs\saas-salao\` (Windows) ou `/opt/lampp/htdocs/saas-salao/` (Linux)

### Passo 2: Configurar Banco de Dados

1. Abra o phpMyAdmin: `http://localhost/phpmyadmin`
2. Clique em "Importar"
3. Selecione o arquivo `database/schema.sql`
4. Clique em "Executar"

Ou execute via linha de comando:
```bash
mysql -u root -p < database/schema.sql
```

### Passo 3: Configurar Conexão (se necessário)

Se suas credenciais do MySQL forem diferentes de padrão, edite o arquivo `config/database.php`:

```php
private $host = "localhost";
private $db_name = "saas_salao";
private $username = "root";      // Altere se necessário
private $password = "";           // Altere se necessário
```

### Passo 4: Iniciar o XAMPP

1. Abra o XAMPP Control Panel
2. Inicie o Apache
3. Inicie o MySQL

### Passo 5: Acessar o Sistema

Abra seu navegador e acesse: `http://localhost/saas-salao/`

## 👤 Login Padrão

- **E-mail:** admin@meusalao.com.br
- **Senha:** admin123

⚠️ **IMPORTANTE:** Altere a senha padrão após o primeiro login!

## 📁 Estrutura de Arquivos

```
saas-salao/
├── api/                           # Endpoints da API REST
│   ├── auth/                     # Autenticação
│   ├── clients/                  # Gestão de clientes
│   ├── services/                 # Gestão de serviços
│   ├── appointments/             # Agendamentos
│   ├── dashboard/                # Estatísticas
│   ├── stock/                    # Estoque
│   └── lgpd/                     # Conformidade LGPD
├── config/                        # Configurações
│   ├── database.php              # Conexão com banco
│   └── security.php              # Funções de segurança
├── database/                      # Scripts SQL
│   └── schema.sql                # Schema completo
├── public/                        # Arquivos públicos
│   ├── css/                      # Estilos ultra profissionais
│   │   ├── main.css              # ✨ Estilos com glassmorphism
│   │   ├── auth.css              # 🌈 Login com gradientes animados
│   │   └── dashboard.css         # 💎 Dashboard ultra sofisticado
│   └── js/                       # JavaScript
│       ├── auth.js               # Autenticação
│       ├── dashboard.js          # Dashboard
│       └── animations.js         # ✨ Animações e efeitos especiais
├── index.php                      # 🎨 Página de login (ultra bonita)
├── dashboard.php                  # 💫 Painel principal (premium)
├── .htaccess                      # Configurações Apache
├── README.md                      # Este arquivo
├── MELHORIAS_VISUAIS.md          # ✨ Documentação das melhorias visuais
└── INSTRUCOES_INSTALACAO.md      # 📖 Guia passo a passo
```

## 🔒 Segurança

- ✅ Senhas com bcrypt (custo 12)
- ✅ Tokens CSRF em todos os formulários
- ✅ Prepared statements (PDO) contra SQL Injection
- ✅ Sanitização contra XSS
- ✅ HttpOnly e SameSite cookies
- ✅ Logs de auditoria
- ✅ Validação de inputs front e backend

## 📊 Banco de Dados

### Principais Tabelas

- **users** - Usuários e profissionais
- **clients** - Clientes do salão
- **services** - Serviços oferecidos
- **appointments** - Agendamentos
- **payments** - Pagamentos
- **stock_items** - Itens do estoque
- **audit_logs** - Logs de auditoria
- **privacy_consents** - Consentimentos LGPD
- **configs** - Configurações do sistema

### Diagrama ER Simplificado

```
users (1) ──< (N) appointments
clients (1) ──< (N) appointments
services (1) ──< (N) appointments
appointments (1) ──< (1) payments
```

## 🔌 Endpoints da API

### Autenticação
- `POST /api/auth/register.php` - Criar conta
- `POST /api/auth/login.php` - Login
- `POST /api/auth/logout.php` - Logout
- `GET /api/auth/me.php` - Dados do usuário logado
- `POST /api/auth/forgot-password.php` - Recuperar senha

### Clientes
- `GET /api/clients/index.php` - Listar clientes
- `POST /api/clients/index.php` - Criar cliente
- `GET /api/clients/single.php?id=X` - Ver cliente
- `PUT /api/clients/single.php?id=X` - Atualizar cliente
- `DELETE /api/clients/single.php?id=X` - Excluir cliente

### Serviços
- `GET /api/services/index.php` - Listar serviços
- `POST /api/services/index.php` - Criar serviço

### Agendamentos
- `GET /api/appointments/index.php?date=YYYY-MM-DD` - Listar agendamentos
- `POST /api/appointments/index.php` - Criar agendamento

### Dashboard
- `GET /api/dashboard/summary.php` - Estatísticas gerais

### LGPD
- `GET /api/lgpd/export-data.php` - Exportar dados (JSON/CSV)
- `POST /api/lgpd/delete-account.php` - Excluir conta

## 🎨 Personalização

### ✨ Efeitos Visuais Incluídos

O sistema já vem com:

- 🌟 **30 partículas** flutuando pelo background
- 🎆 **50 confetes** animados ao fazer login
- 💫 **Animações suaves** em todos os elementos
- 🎨 **Gradientes que se movem** (15s animation)
- ✨ **Efeito ripple** nos botões
- 💎 **Glassmorphism** em cards e modais
- 🌓 **Modo claro/escuro** com transição de 0.5s

### Alterar Cores (Tema)

Edite o arquivo `public/css/main.css`:

```css
:root {
    --primary: #e91e63;        /* Rosa principal */
    --secondary: #9c27b0;      /* Roxo/lilás */
    --accent: #d4af37;         /* Dourado */
    --gradient-primary: linear-gradient(135deg, #e91e63 0%, #9c27b0 50%, #673ab7 100%);
}
```

**Dica:** Para desativar as partículas ou confete, comente as funções em `public/js/animations.js`

### Alterar Logo

Substitua o emoji 💅 nos arquivos `index.php` e `dashboard.php` por uma tag `<img>`:

```html
<img src="public/images/logo.png" alt="Logo" style="height: 40px;">
```

## 🔄 Backup e Restauração

### Criar Backup

```bash
mysqldump -u root -p saas_salao > backup_$(date +%Y%m%d).sql
```

### Restaurar Backup

```bash
mysql -u root -p saas_salao < backup_20250122.sql
```

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- 💻 Desktop
- 📱 Tablets
- 📱 Smartphones

## 🚀 Roadmap Futuro

### v1.1 - Pro
- [ ] Multiusuário com agendas individuais
- [ ] Cálculo de comissões
- [ ] Gateway real de pagamentos (Stripe/MercadoPago)
- [ ] Lembretes automáticos por e-mail/WhatsApp

### v2.0 - Premium
- [ ] Integração WhatsApp Business API
- [ ] Sincronização com Google Calendar
- [ ] Chatbot de agendamento com IA
- [ ] Relatórios preditivos
- [ ] Programa de fidelidade automático

## 🐛 Solução de Problemas

### Erro de Conexão com Banco
- Verifique se o MySQL está rodando no XAMPP
- Confirme as credenciais em `config/database.php`
- Certifique-se de que o banco `saas_salao` foi criado

### Página em Branco
- Ative o display de erros no `php.ini`:
  ```ini
  display_errors = On
  error_reporting = E_ALL
  ```
- Verifique os logs do Apache em `C:\xampp\apache\logs\error.log`

### Sessão não Funciona
- Verifique permissões da pasta de sessões do PHP
- Certifique-se de que `session.save_path` está configurado no `php.ini`

## 📄 Licença

Este projeto é fornecido "como está" para uso em ambiente local.

## 👨‍💻 Suporte

Para dúvidas e suporte:
1. Verifique este README
2. Consulte os comentários no código
3. Revise os logs de erro do Apache/PHP

## 🎯 Checklist de Segurança

- [x] Senhas com bcrypt
- [x] CSRF tokens
- [x] Prepared statements
- [x] Sanitização XSS
- [x] HTTPS recomendado (produção)
- [x] Cookies seguros
- [x] Logs de auditoria
- [x] Conformidade LGPD
- [x] Backup automatizável

---

**Desenvolvido com ❤️ para salões e profissionais de beleza**
