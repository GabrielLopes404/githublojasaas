let currentUser = null;
let csrfToken = '';
let currentView = 'dashboard';

document.addEventListener('DOMContentLoaded', async function() {
    await checkAuth();
    initTheme();
    initNavigation();
    loadDashboard();
});

async function checkAuth() {
    try {
        const response = await fetch('/api/auth/me.php');
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            csrfToken = data.csrf_token;
            updateUserInfo();
        } else {
            window.location.href = '/index.php';
        }
    } catch (error) {
        window.location.href = '/index.php';
    }
}

function updateUserInfo() {
    const userName = document.getElementById('user-name');
    const userEmail = document.getElementById('user-email');
    const userAvatar = document.getElementById('user-avatar');
    
    if (userName) userName.textContent = currentUser.name;
    if (userEmail) userEmail.textContent = currentUser.email;
    if (userAvatar) userAvatar.textContent = currentUser.name.charAt(0).toUpperCase();
}

function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
        updateThemeIcon();
    }
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
}

function updateThemeIcon() {
    const theme = document.documentElement.getAttribute('data-theme');
    const icon = document.getElementById('theme-toggle');
    if (icon) {
        icon.textContent = theme === 'light' ? '🌙' : '☀️';
    }
}

function initNavigation() {
    const navLinks = document.querySelectorAll('.sidebar-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const view = this.dataset.view;
            switchView(view);
            
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    document.getElementById('logout-btn')?.addEventListener('click', handleLogout);
    document.getElementById('mobile-menu-btn')?.addEventListener('click', toggleMobileMenu);
}

function switchView(view) {
    currentView = view;
    const mainContent = document.getElementById('main-content-area');
    
    switch(view) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'calendar':
            loadCalendar();
            break;
        case 'clients':
            loadClients();
            break;
        case 'services':
            loadServices();
            break;
        case 'financial':
            loadFinancial();
            break;
        case 'stock':
            loadStock();
            break;
        case 'reports':
            loadReports();
            break;
        case 'settings':
            loadSettings();
            break;
    }
}

async function loadDashboard() {
    try {
        const response = await fetch('/api/dashboard/summary.php');
        const data = await response.json();
        
        if (data.success) {
            renderDashboard(data);
        }
    } catch (error) {
        showAlert('error', 'Erro ao carregar dashboard');
    }
}

function renderDashboard(data) {
    const content = document.getElementById('main-content-area');
    
    createConfetti();
    
    content.innerHTML = `
        <div class="stats-grid">
            <div class="stat-card">
                <h3>${data.today.total || 0}</h3>
                <p>Agendamentos Hoje</p>
            </div>
            <div class="stat-card">
                <h3>${data.month.completed || 0}</h3>
                <p>Atendimentos este Mês</p>
            </div>
            <div class="stat-card">
                <h3>R$ ${parseFloat(data.month.revenue || 0).toFixed(2)}</h3>
                <p>Faturamento Mensal</p>
            </div>
            <div class="stat-card">
                <h3>${data.totals.clients || 0}</h3>
                <p>Clientes Ativos</p>
            </div>
        </div>
        
        <div class="grid grid-2" style="margin-top: 30px;">
            <div class="card">
                <h3 style="margin-bottom: 16px; color: var(--primary);">Próximos Agendamentos</h3>
                <div id="upcoming-appointments"></div>
            </div>
            
            <div class="card">
                <h3 style="margin-bottom: 16px; color: --primary);">Serviços Mais Populares</h3>
                <div id="top-services"></div>
            </div>
        </div>
    `;
    
    const upcomingDiv = document.getElementById('upcoming-appointments');
    if (data.upcoming && data.upcoming.length > 0) {
        upcomingDiv.innerHTML = data.upcoming.map(apt => `
            <div class="appointment-item" style="margin-bottom: 12px;">
                <div style="font-weight: bold; color: var(--primary);">
                    ${formatDate(apt.appointment_date)} às ${formatTime(apt.appointment_time)}
                </div>
                <div>${apt.client_name} - ${apt.service_name}</div>
            </div>
        `).join('');
    } else {
        upcomingDiv.innerHTML = '<p style="color: var(--text-secondary);">Nenhum agendamento próximo</p>';
    }
    
    const topServicesDiv = document.getElementById('top-services');
    if (data.top_services && data.top_services.length > 0) {
        topServicesDiv.innerHTML = data.top_services.map(service => `
            <div style="margin-bottom: 12px; padding: 10px; background: var(--background); border-radius: 6px;">
                <div style="font-weight: 500;">${service.name}</div>
                <div style="font-size: 13px; color: var(--text-secondary);">
                    ${service.count} atendimentos - R$ ${parseFloat(service.revenue || 0).toFixed(2)}
                </div>
            </div>
        `).join('');
    } else {
        topServicesDiv.innerHTML = '<p style="color: var(--text-secondary);">Sem dados disponíveis</p>';
    }
}

async function handleLogout() {
    try {
        await fetch('/api/auth/logout.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ csrf_token: csrfToken })
        });
        
        window.location.href = '/index.php';
    } catch (error) {
        window.location.href = '/index.php';
    }
}

function toggleMobileMenu() {
    document.querySelector('.sidebar').classList.toggle('active');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function formatTime(timeString) {
    return timeString.substring(0, 5);
}

function showAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '9999';
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.style.opacity = '0';
        setTimeout(() => alertDiv.remove(), 300);
    }, 5000);
}

function loadCalendar() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Agenda</h2>
            <p style="color: var(--text-secondary);">Calendário de agendamentos em desenvolvimento...</p>
        </div>
    `;
}

function loadClients() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Clientes</h2>
            <p style="color: var(--text-secondary);">Gestão de clientes em desenvolvimento...</p>
        </div>
    `;
}

function loadServices() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Serviços</h2>
            <p style="color: var(--text-secondary);">Gestão de serviços em desenvolvimento...</p>
        </div>
    `;
}

function loadFinancial() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Financeiro</h2>
            <p style="color: var(--text-secondary);">Módulo financeiro em desenvolvimento...</p>
        </div>
    `;
}

function loadStock() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Estoque</h2>
            <p style="color: var(--text-secondary);">Controle de estoque em desenvolvimento...</p>
        </div>
    `;
}

function loadReports() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Relatórios</h2>
            <p style="color: var(--text-secondary);">Relatórios em desenvolvimento...</p>
        </div>
    `;
}

function loadSettings() {
    document.getElementById('main-content-area').innerHTML = `
        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 20px;">Configurações</h2>
            <p style="color: var(--text-secondary);">Configurações em desenvolvimento...</p>
        </div>
    `;
}
