document.addEventListener('DOMContentLoaded', function() {
    initParticles();
    initScrollAnimations();
    initHoverEffects();
    initLoadingAnimations();
});

function initParticles() {
    const particlesContainer = document.createElement('div');
    particlesContainer.id = 'particles-container';
    particlesContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
        overflow: hidden;
    `;
    
    document.body.insertBefore(particlesContainer, document.body.firstChild);
    
    for (let i = 0; i < 30; i++) {
        createParticle(particlesContainer);
    }
}

function createParticle(container) {
    const particle = document.createElement('div');
    const size = Math.random() * 4 + 2;
    const startX = Math.random() * window.innerWidth;
    const duration = Math.random() * 20 + 10;
    const delay = Math.random() * 5;
    
    particle.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: radial-gradient(circle, rgba(233, 30, 99, 0.6), rgba(156, 39, 176, 0.3));
        border-radius: 50%;
        top: 100%;
        left: ${startX}px;
        animation: floatUp ${duration}s linear ${delay}s infinite;
        box-shadow: 0 0 10px rgba(233, 30, 99, 0.5);
    `;
    
    container.appendChild(particle);
}

const floatUpAnimation = `
@keyframes floatUp {
    from {
        transform: translateY(0) translateX(0) scale(1);
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    90% {
        opacity: 1;
    }
    to {
        transform: translateY(-100vh) translateX(${Math.random() * 200 - 100}px) scale(0);
        opacity: 0;
    }
}
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = floatUpAnimation;
document.head.appendChild(styleSheet);

function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.card, .stat-card, .appointment-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

function initHoverEffects() {
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.style.cssText = `
                position: absolute;
                width: 20px;
                height: 20px;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                left: ${x}px;
                top: ${y}px;
                transform: translate(-50%, -50%) scale(0);
                animation: ripple 0.6s ease-out;
                pointer-events: none;
            `;
            
            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });
    });
    
    const rippleAnimation = `
    @keyframes ripple {
        to {
            transform: translate(-50%, -50%) scale(20);
            opacity: 0;
        }
    }
    `;
    
    const style = document.createElement('style');
    style.textContent = rippleAnimation;
    document.head.appendChild(style);
}

function initLoadingAnimations() {
    const loadingElements = document.querySelectorAll('.loading');
    
    loadingElements.forEach(loader => {
        const dots = document.createElement('div');
        dots.className = 'loading-dots';
        dots.innerHTML = '<span></span><span></span><span></span>';
        dots.style.cssText = `
            display: inline-flex;
            gap: 6px;
            margin-left: 10px;
        `;
        
        dots.querySelectorAll('span').forEach((dot, i) => {
            dot.style.cssText = `
                width: 8px;
                height: 8px;
                background: var(--primary);
                border-radius: 50%;
                animation: dotBounce 1.4s ease-in-out ${i * 0.2}s infinite;
            `;
        });
        
        if (loader.parentElement) {
            loader.parentElement.appendChild(dots);
        }
    });
    
    const dotBounceAnimation = `
    @keyframes dotBounce {
        0%, 80%, 100% {
            transform: translateY(0);
            opacity: 0.6;
        }
        40% {
            transform: translateY(-12px);
            opacity: 1;
        }
    }
    `;
    
    const style = document.createElement('style');
    style.textContent = dotBounceAnimation;
    document.head.appendChild(style);
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? 'linear-gradient(135deg, #4caf50, #66bb6a)' : 'linear-gradient(135deg, #f44336, #ef5350)'};
        color: white;
        border-radius: 16px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        animation: slideInRight 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        font-weight: 600;
        backdrop-filter: blur(10px);
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.5s ease forwards';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

const notificationAnimations = `
@keyframes slideInRight {
    from {
        transform: translateX(400px);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOutRight {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(400px);
        opacity: 0;
    }
}
`;

const notifStyle = document.createElement('style');
notifStyle.textContent = notificationAnimations;
document.head.appendChild(notifStyle);

function createConfetti() {
    const colors = ['#e91e63', '#9c27b0', '#673ab7', '#d4af37', '#f48fb1'];
    
    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.random() * 10 + 5;
        const startX = Math.random() * window.innerWidth;
        const duration = Math.random() * 3 + 2;
        const delay = Math.random() * 0.5;
        
        confetti.style.cssText = `
            position: fixed;
            width: ${size}px;
            height: ${size}px;
            background: ${color};
            top: -10px;
            left: ${startX}px;
            border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
            animation: confettiFall ${duration}s linear ${delay}s forwards;
            z-index: 9999;
            pointer-events: none;
        `;
        
        document.body.appendChild(confetti);
        
        setTimeout(() => confetti.remove(), (duration + delay) * 1000);
    }
}

const confettiAnimation = `
@keyframes confettiFall {
    to {
        transform: translateY(100vh) rotate(${Math.random() * 720}deg);
        opacity: 0;
    }
}
`;

const confettiStyle = document.createElement('style');
confettiStyle.textContent = confettiAnimation;
document.head.appendChild(confettiStyle);

window.showNotification = showNotification;
window.createConfetti = createConfetti;
