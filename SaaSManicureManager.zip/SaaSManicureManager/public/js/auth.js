let csrfToken = '';

document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/auth/me.php')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.href = '/dashboard.php';
            } else {
                csrfToken = data.csrf_token || getCookie('csrf_token');
            }
        })
        .catch(() => {});
    
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.dataset.tab;
            switchTab(tab);
        });
    });
    
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('register-form').addEventListener('submit', handleRegister);
    document.getElementById('forgot-form')?.addEventListener('submit', handleForgotPassword);
    
    document.getElementById('show-forgot')?.addEventListener('click', function(e) {
        e.preventDefault();
        showForgotTab();
    });
    
    document.getElementById('back-to-login')?.addEventListener('click', function() {
        switchTab('login');
    });
});

function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    const activeBtn = document.querySelector(`[data-tab="${tab}"]`);
    const activeContent = document.getElementById(`${tab}-tab`);
    
    if (activeBtn) activeBtn.classList.add('active');
    if (activeContent) activeContent.classList.add('active');
}

function showForgotTab() {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById('forgot-tab').classList.add('active');
}

async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    try {
        const response = await fetch('/api/auth/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, csrf_token: csrfToken })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('success', data.message);
            if (typeof createConfetti === 'function') {
                createConfetti();
            }
            setTimeout(() => {
                window.location.href = '/dashboard.php';
            }, 1000);
        } else {
            showAlert('error', data.message);
        }
    } catch (error) {
        showAlert('error', 'Erro ao fazer login');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const phone = document.getElementById('register-phone').value;
    const password = document.getElementById('register-password').value;
    const confirm_password = document.getElementById('register-confirm').value;
    
    if (password !== confirm_password) {
        showAlert('error', 'As senhas não conferem');
        return;
    }
    
    try {
        const response = await fetch('/api/auth/register.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                name, email, phone, password, confirm_password, csrf_token: csrfToken 
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('success', data.message);
            setTimeout(() => {
                switchTab('login');
            }, 1500);
        } else {
            showAlert('error', data.message);
        }
    } catch (error) {
        showAlert('error', 'Erro ao criar conta');
    }
}

async function handleForgotPassword(e) {
    e.preventDefault();
    
    const email = document.getElementById('forgot-email').value;
    
    try {
        const response = await fetch('/api/auth/forgot-password.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, csrf_token: csrfToken })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('success', data.message);
            if (data.debug_token) {
                showAlert('info', `Token de recuperação (desenvolvimento): ${data.debug_token}`);
            }
        } else {
            showAlert('error', data.message);
        }
    } catch (error) {
        showAlert('error', 'Erro ao processar solicitação');
    }
}

function showAlert(type, message) {
    const container = document.getElementById('alert-container');
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    
    container.appendChild(alert);
    
    setTimeout(() => {
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }, 5000);
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return '';
}
