# 🚀 Instruções de Instalação - SaaS para Salões

## ⚠️ IMPORTANTE

Este sistema foi desenvolvido para rodar **no seu computador local com XAMPP**, conforme solicitado.

## 📥 Passo a Passo de Instalação

### 1️⃣ Baixar o Projeto

Faça download de todos os arquivos deste projeto ou clone o repositório para seu computador.

### 2️⃣ Instalar o XAMPP

Se ainda não tem o XAMPP instalado:

1. Baixe em: https://www.apachefriends.org/
2. Instale o XAMPP (Apache + PHP 8.x + MySQL)
3. Execute o XAMPP Control Panel

### 3️⃣ Copiar os Arquivos

Copie **todos os arquivos** deste projeto para a pasta do XAMPP:

**Windows:**
```
C:\xampp\htdocs\saas-salao\
```

**Linux/Mac:**
```
/opt/lampp/htdocs/saas-salao/
```

### 4️⃣ Criar o Banco de Dados

#### Opção A: Via phpMyAdmin (Recomendado)

1. Abra o navegador e acesse: `http://localhost/phpmyadmin`
2. Clique em "Novo" (New) no painel esquerdo
3. Nome do banco: `saas_salao`
4. Codificação: `utf8mb4_unicode_ci`
5. Clique em "Criar"
6. Clique em "Importar" (Import)
7. Escolha o arquivo: `database/schema.sql`
8. Clique em "Executar" (Go)

#### Opção B: Via Linha de Comando

```bash
cd C:\xampp\mysql\bin
mysql -u root -p
```

Dentro do MySQL:
```sql
CREATE DATABASE saas_salao CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit;
```

Depois importe o schema:
```bash
mysql -u root -p saas_salao < C:\caminho\para\database\schema.sql
```

### 5️⃣ Iniciar os Serviços

No XAMPP Control Panel:

1. ✅ Clique em "Start" no **Apache**
2. ✅ Clique em "Start" no **MySQL**

### 6️⃣ Acessar o Sistema

Abra seu navegador e acesse:

```
http://localhost/saas-salao/
```

### 7️⃣ Fazer Login

Use as credenciais padrão:

- **E-mail:** `admin@meusalao.com.br`
- **Senha:** `admin123`

⚠️ **IMPORTANTE:** Altere a senha após o primeiro acesso!

## 🔧 Configurações Adicionais (Se Necessário)

### Mudar Credenciais do Banco

Se suas credenciais do MySQL forem diferentes, edite o arquivo:

**config/database.php**

```php
private $host = "localhost";
private $db_name = "saas_salao";
private $username = "root";      // Altere aqui
private $password = "";           // Altere aqui
```

### Habilitar Erros PHP (Para Desenvolvimento)

Edite o arquivo `C:\xampp\php\php.ini`:

```ini
display_errors = On
error_reporting = E_ALL
```

Reinicie o Apache após a alteração.

## ✅ Verificar se Está Funcionando

Após acessar `http://localhost/saas-salao/`:

1. ✅ Você deve ver a tela de login com tema rosé/lilás
2. ✅ Faça login com as credenciais padrão
3. ✅ Você deve ser redirecionado para o Dashboard
4. ✅ Verifique se as estatísticas aparecem
5. ✅ Teste criar um cliente, serviço ou agendamento

## 📱 Estrutura do Sistema

### Módulos Disponíveis

- 📊 **Dashboard** - Estatísticas e visão geral
- 📅 **Agenda** - Calendário de agendamentos
- 👥 **Clientes** - Gestão de clientes
- ✨ **Serviços** - Catálogo de serviços
- 💰 **Financeiro** - Controle financeiro
- 📦 **Estoque** - Controle de produtos
- 📈 **Relatórios** - Análises e relatórios
- ⚙️ **Configurações** - Personalização

### Dados de Exemplo Incluídos

O banco já vem com:

- ✅ 1 usuário administrador
- ✅ 5 serviços de exemplo
- ✅ 5 produtos de estoque de exemplo
- ✅ Configurações básicas do sistema

## 🎨 Personalização

### Alterar Cores do Tema

Edite o arquivo `public/css/main.css`:

```css
:root {
    --primary: #e91e63;      /* Rosa/Pink */
    --secondary: #9c27b0;    /* Lilás/Roxo */
    --accent: #d4af37;       /* Dourado */
}
```

### Alterar Nome do Salão

Edite no banco de dados:

```sql
UPDATE configs SET config_value = 'Nome do Seu Salão' 
WHERE config_key = 'business_name';
```

Ou diretamente no código `dashboard.php` e `index.php`.

## 🔒 Segurança

O sistema já inclui:

- ✅ Senhas criptografadas com bcrypt
- ✅ Proteção contra SQL Injection (prepared statements)
- ✅ Proteção contra XSS (sanitização)
- ✅ Tokens CSRF em formulários
- ✅ Cookies seguros (HttpOnly)
- ✅ Logs de auditoria

### Para Produção (Internet):

1. ✅ Use HTTPS (certificado SSL)
2. ✅ Altere TODAS as senhas padrão
3. ✅ Configure backup automático
4. ✅ Restrinja acesso ao phpMyAdmin
5. ✅ Atualize o PHP regularmente

## 💾 Backup

### Fazer Backup do Banco

```bash
cd C:\xampp\mysql\bin
mysqldump -u root -p saas_salao > backup_20250122.sql
```

### Restaurar Backup

```bash
mysql -u root -p saas_salao < backup_20250122.sql
```

## 🐛 Problemas Comuns

### "Erro de Conexão com o Banco"

- ✅ Verifique se o MySQL está rodando no XAMPP
- ✅ Confirme as credenciais em `config/database.php`
- ✅ Certifique-se de que o banco `saas_salao` foi criado

### "Página em Branco"

- ✅ Verifique os logs: `C:\xampp\apache\logs\error.log`
- ✅ Ative `display_errors` no `php.ini`
- ✅ Reinicie o Apache

### "Permissão Negada"

- ✅ Execute o XAMPP como Administrador (Windows)
- ✅ Verifique permissões das pastas (Linux)

## 📞 Próximos Passos

1. ✅ Personalize o nome do seu salão
2. ✅ Altere a senha padrão
3. ✅ Cadastre seus serviços reais
4. ✅ Adicione produtos ao estoque
5. ✅ Comece a cadastrar clientes
6. ✅ Faça seus primeiros agendamentos

## 📚 Documentação Completa

Leia o arquivo `README.md` para:

- Documentação completa da API
- Lista de todos os endpoints
- Estrutura detalhada do banco
- Guia de desenvolvimento
- Roadmap de funcionalidades futuras

---

**Sistema 100% funcional e pronto para uso! 🎉**

Se tiver dúvidas, verifique os comentários no código - tudo está documentado!
